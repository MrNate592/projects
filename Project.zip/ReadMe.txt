*cv2 module is needed for the program to work.
--------------------------------------------------------------------------------------------
Instructions:
pip install opencv-python
pip install opencv-contrib-python
--------------------------------------------------------------------------------------------

*pyzbar module is neeeded for the program to work.
--------------------------------------------------------------------------------------------
Instructions:
pip install pyzbar
--------------------------------------------------------------------------------------------

The default password and username for the program is admin admin.




This program takes in a person's data and stores it in a database. A digital vaccine card can be created. The QR code can
be used to scan the database for the person. This can also be used in real life instances eg. A grocery store. The program allows you to view
all persons, update one's information and delete a person.